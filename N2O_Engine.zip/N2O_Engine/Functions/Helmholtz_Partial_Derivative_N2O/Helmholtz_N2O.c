/**************************************************
*  author:  @J1E
*  program function:  Helmholtz energy & partial derivative
*  time:  @2022
***************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define tc 309.52
#define dc 452.0115
#define R 188.9


//...Helmholtz energy & partial derivative
double dpdrho(double t, double d)
{
  double dpdrho;
  double x=d/dc;
  double y=tc/t;

  double n[12]={0.88045, -2.4235, 0.38237, 0.068917, 0.00020367,
                0.13122, 0.46032, -0.0036985, -0.23263, -0.00042859,
                -0.042810, -0.023038};

  double n1=n[0], n2=n[1], n3=n[2], n4=n[3], n5=n[4], n6=n[5],
         n7=n[6], n8=n[7], n9=n[8], n10=n[9], n11=n[10], n12=n[11];

  double aro,aroo;

  aro = n1*pow(y,1/4) + n3*pow(y,3/2) + n2*pow(y,5/4) + n9*pow(y,7/2)*exp(-x*x) + n10*pow(y,13/2)*exp(-x*x)
  + 3*n4*x*x*pow(y,1/4) + 7*n5*pow(x,6)*pow(y,7/8) + n6*pow(y,19/8)*exp(-x) - 2*n9*x*x*pow(y,7/2)*exp(-x*x)
  - 2*n10*x*x*pow(y,13/2)*exp(-x*x) + 4*n11*pow(x,3)*pow(y,19/4)*exp(-x*x) - 2*n11*pow(x,5)*pow(y,19/4)*exp(-x*x)
  - 3*n12*pow(x,4)*pow(y,25/2)*exp(-x*x*x) + 2*n7*x*y*y*exp(-x) - n6*x*pow(y,19/8)*exp(-x) - n7*x*x*y*y*exp(-x)
  + 5*n8*pow(x,4)*pow(y,17/8)*exp(-x) - n8*pow(x,5)*pow(y,17/8)*exp(-x) + 2*n12*x*pow(y,25/2)*exp(-x*x*x);

  aroo = 6*n4*x*pow(y,1/4) + 2*n12*pow(y,25/2)*exp(-x*x*x) + 42*n5*pow(x,5)*pow(y,7/8) + 2*n7*y*y*exp(-x)
  - 2*n6*pow(y,19/8)*exp(-x) + 4*n9*pow(x,3)*pow(y,7/2)*exp(-x*x) + 4*n10*pow(x,3)*pow(y,13/2)*exp(-x*x)
  + 12*n11*x*x*pow(y,19/4)*exp(-x*x) - 18*n11*pow(x,4)*pow(y,19/4)*exp(-x*x) + 4*n11*pow(x,6)*pow(y,19/4)*exp(-x*x)
  - 18*n12*pow(x,3)*pow(y,25/2)*exp(-x*x*x) + 9*n12*pow(x,6)*pow(y,25/2)*exp(-x*x*x) - 4*n7*x*y*y*exp(-x)
  + n6*x*pow(y,19/8)*exp(-x) + n7*x*x*y*y*exp(-x) - 6*n9*x*pow(y,7/2)*exp(-x*x) - 6*n10*x*pow(y,13/2)*exp(-x*x)
  + 20*n8*pow(x,3)*pow(y,17/8)*exp(-x) - 10*n8*pow(x,4)*pow(y,17/8)*exp(-x) + n8*pow(x,5)*pow(y,17/8)*exp(-x);

  dpdrho=t*R*(1+2*x*aro+x*x*aroo);

  return dpdrho;
}


double dpdt(double t, double d)
{
  double dpdt;
  double x=d/dc;
  double y=tc/t;

  double n[12]={0.88045, -2.4235, 0.38237, 0.068917, 0.00020367,
                0.13122, 0.46032, -0.0036985, -0.23263, -0.00042859,
                -0.042810, -0.023038};
  double n1=n[0], n2=n[1], n3=n[2], n4=n[3], n5=n[4], n6=n[5],
         n7=n[6], n8=n[7], n9=n[8], n10=n[9], n11=n[10], n12=n[11];

  double aro,arto;

  aro = n1*pow(y,1/4) + n3*pow(y,3/2) + n2*pow(y,5/4) + n9*pow(y,7/2)*exp(-x*x) + n10*pow(y,13/2)*exp(-x*x)
  + 3*n4*x*x*pow(y,1/4) + 7*n5*pow(x,6)*pow(y,7/8) + n6*pow(y,19/8)*exp(-x) - 2*n9*x*x*pow(y,7/2)*exp(-x*x)
  - 2*n10*x*x*pow(y,13/2)*exp(-x*x) + 4*n11*pow(x,3)*pow(y,19/4)*exp(-x*x) - 2*n11*pow(x,5)*pow(y,19/4)*exp(-x*x)
  - 3*n12*pow(x,4)*pow(y,25/2)*exp(-x*x*x) + 2*n7*x*y*y*exp(-x) - n6*x*pow(y,19/8)*exp(-x) - n7*x*x*y*y*exp(-x)
  + 5*n8*pow(x,4)*pow(y,17/8)*exp(-x) - n8*pow(x,5)*pow(y,17/8)*exp(-x) + 2*n12*x*pow(y,25/2)*exp(-x*x*x);

  arto = (3*n3*pow(y,1/2))/2 + (5*n2*pow(y,1/4))/4 + n1/(4*pow(y,3/4)) + (7*n9*pow(y,5/2)*exp(-x*x))/2
  + (13*n10*pow(y,11/2)*exp(-x*x))/2 + (3*n4*x*x)/(4*pow(y,3/4)) + (49*n5*pow(x,6))/(8*pow(y,1/8))
  + (19*n6*pow(y,11/8)*exp(-x))/8 - 7*n9*x*x*pow(y,5/2)*exp(-x*x) - 13*n10*x*x*pow(y,11/2)*exp(-x*x)
  + 19*n11*pow(x,3)*pow(y,15/4)*exp(-x*x) - (19*n11*pow(x,5)*pow(y,15/4)*exp(-x*x))/2 - (75*n12*pow(x,4)*pow(y,23/2)*exp(-x*x*x))/2
  - 2*n7*x*x*y*exp(-x) - (19*n6*x*pow(y,11/8)*exp(-x))/8 + (85*n8*pow(x,4)*pow(y,9/8)*exp(-x))/8
  - (17*n8*pow(x,5)*pow(y,9/8)*exp(-x))/8 + 25*n12*x*pow(y,23/2)*exp(-x*x*x) + 4*n7*x*y*exp(-x);

  dpdt=d*R*(1+x*aro-x*y*arto);

  return dpdt;
}


double dudrho(double t, double d)
{
  double dudrho;
  double x=d/dc;
  double y=tc/t;

  double n[12]={0.88045, -2.4235, 0.38237, 0.068917, 0.00020367,
                0.13122, 0.46032, -0.0036985, -0.23263, -0.00042859,
                -0.042810, -0.023038};
  double n1=n[0], n2=n[1], n3=n[2], n4=n[3], n5=n[4], n6=n[5],
         n7=n[6], n8=n[7], n9=n[8], n10=n[9], n11=n[10], n12=n[11];

  double arto;

  arto = (3*n3*pow(y,1/2))/2 + (5*n2*pow(y,1/4))/4 + n1/(4*pow(y,3/4)) + (7*n9*pow(y,5/2)*exp(-x*x))/2
  + (13*n10*pow(y,11/2)*exp(-x*x))/2 + (3*n4*x*x)/(4*pow(y,3/4)) + (49*n5*pow(x,6))/(8*pow(y,1/8))
  + (19*n6*pow(y,11/8)*exp(-x))/8 - 7*n9*x*x*pow(y,5/2)*exp(-x*x) - 13*n10*x*x*pow(y,11/2)*exp(-x*x)
  + 19*n11*pow(x,3)*pow(y,15/4)*exp(-x*x) - (19*n11*pow(x,5)*pow(y,15/4)*exp(-x*x))/2 - (75*n12*pow(x,4)*pow(y,23/2)*exp(-x*x*x))/2
  - 2*n7*x*x*y*exp(-x) - (19*n6*x*pow(y,11/8)*exp(-x))/8 + (85*n8*pow(x,4)*pow(y,9/8)*exp(-x))/8
  - (17*n8*pow(x,5)*pow(y,9/8)*exp(-x))/8 + 25*n12*x*pow(y,23/2)*exp(-x*x*x) + 4*n7*x*y*exp(-x);

  dudrho=t*R/d*(x*y*arto);

  return dudrho;
}


double dudt(double t, double d)
{
  double dudt;
  double x=d/dc;
  double y=tc/t;

  double n[12]={0.88045, -2.4235, 0.38237, 0.068917, 0.00020367,
                0.13122, 0.46032, -0.0036985, -0.23263, -0.00042859,
                -0.042810, -0.023038};
  double n1=n[0], n2=n[1], n3=n[2], n4=n[3], n5=n[4], n6=n[5],
         n7=n[6], n8=n[7], n9=n[8], n10=n[9], n11=n[10], n12=n[11];

  double a[2]={-4.4262736272, 4.3120175243};
  double c[3]={3.5, 0, 0};
  double v[5]={2.1769, 1.6145, 0.48393};
  double u[5]={879.0, 2372.0, 5447.0};
  double a1=a[0], a2=a[1], c0=c[0], c1=c[1], c2=c[2],
         v1=v[0], v2=v[1], v3=v[2],
         u1=u[0], u2=u[1], u3=u[2];

  double a0tt,artt;

  a0tt = (u1*u1*v1*exp(-(u1*y)/tc))/(tc*tc*(exp(-(u1*y)/tc) - 1)) - (c1*pow(tc,c2))/pow(y,(c2 + 2))
  - (c0 - 1)/y/y - (u1*u1*v1*exp(-(2*u1*y)/tc))/(tc*tc*pow((exp(-(u1*y)/tc) - 1),2))
  + (u2*u2*v2*exp(-(u2*y)/tc))/(tc*tc*(exp(-(u2*y)/tc) - 1))
  - (u2*u2*v2*exp(-(2*u2*y)/tc))/(tc*tc*pow((exp(-(u2*y)/tc) - 1),2))
  + (u3*u3*v3*exp(-(u3*y)/tc))/(tc*tc*(exp(-(u3*y)/tc) - 1))
  - (u3*u3*v3*exp(-(2*u3*y)/tc))/(tc*tc*pow((exp(-(u3*y)/tc) - 1),2));

  artt = (3*n3*x)/(4*pow(y,1/2)) + (5*n2*x)/(16*pow(y,3/4)) - (3*n1*x)/(16*pow(y,7/4))
  - (3*n4*pow(x,3))/(16*pow(y,7/4)) - (7*n5*pow(x,7))/(64*pow(y,9/8)) + 2*n7*x*x*exp(-x)
  + (285*n11*pow(x,4)*pow(y,11/4)*exp(-x*x))/16 + (575*n12*x*x*pow(y,21/2)*exp(-x*x*x))/4
  + (209*n6*x*pow(y,3/8)*exp(-x))/64 + (35*n9*x*pow(y,3/2)*exp(-x*x))/4
  + (153*n8*pow(x,5)*pow(y,1/8)*exp(-x))/64 + (143*n10*x*pow(y,9/2)*exp(-x*x))/4;

  dudt=-R*y*y*(a0tt+artt);

  return dudt;
}

/*
//...main() function used to debug
int main()
{
  double t=288, d=100;
  double dut,dud;
  dut=dudt(t,d);
  dud=dudrho(t,d);

  printf("dudt=%lf\n",dut);
  printf("dudrho=%lf\n",dud);

  return 0;
}
*/







