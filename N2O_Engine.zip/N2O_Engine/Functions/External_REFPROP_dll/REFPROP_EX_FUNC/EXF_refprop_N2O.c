/**************************************************
*  author:  @J1E
*  program function:  external_refpropdll
*  time:  @2022
*  thanks to Ian Bell
***************************************************/

#include <windows.h>
#include <stdio.h>
#include "F:\refprop_dll_file\refprop2.h"
#include <math.h>

#define refpropcharlength 255
#define filepathlength 255
#define lengthofreference 3
#define errormessagelength 255
#define ncmax 20
#define numparams 72
#define maxcoefs 50
#define pi 3.1415926
#define Ru 8314
#define Diam 0.1   //...diameter
#define height 1   //...height of tank


void Linkdll()
{
  //...First create a pointer to an instance of the library
  //...Then have windows load the library.
  HINSTANCE RefpropdllInstance;

  //...This looks only in the current directory for refprop.dll
  RefpropdllInstance = LoadLibrary("F:\\refprop_dll_file\\refprop.dll");

	ABFL1dll = (fp_ABFL1dllTYPE) GetProcAddress(RefpropdllInstance,"ABFL1dll");
	ABFL2dll = (fp_ABFL2dllTYPE) GetProcAddress(RefpropdllInstance,"ABFL2dll");
	ACTVYdll = (fp_ACTVYdllTYPE) GetProcAddress(RefpropdllInstance,"ACTVYdll");
	AGdll = (fp_AGdllTYPE) GetProcAddress(RefpropdllInstance,"AGdll");
	CCRITdll = (fp_CCRITdllTYPE) GetProcAddress(RefpropdllInstance,"CCRITdll");
	CP0dll = (fp_CP0dllTYPE) GetProcAddress(RefpropdllInstance,"CP0dll");
	CRITPdll = (fp_CRITPdllTYPE) GetProcAddress(RefpropdllInstance,"CRITPdll");
	CSATKdll = (fp_CSATKdllTYPE) GetProcAddress(RefpropdllInstance,"CSATKdll");
	CV2PKdll = (fp_CV2PKdllTYPE) GetProcAddress(RefpropdllInstance,"CV2PKdll");
	CVCPKdll = (fp_CVCPKdllTYPE) GetProcAddress(RefpropdllInstance,"CVCPKdll");
	CVCPdll = (fp_CVCPdllTYPE) GetProcAddress(RefpropdllInstance,"CVCPdll"); //**
	DBDTdll = (fp_DBDTdllTYPE) GetProcAddress(RefpropdllInstance,"DBDTdll");
	DBFL1dll = (fp_DBFL1dllTYPE) GetProcAddress(RefpropdllInstance,"DBFL1dll");
	DBFL2dll = (fp_DBFL2dllTYPE) GetProcAddress(RefpropdllInstance,"DBFL2dll");
	DDDPdll = (fp_DDDPdllTYPE) GetProcAddress(RefpropdllInstance,"DDDPdll");
	DDDTdll = (fp_DDDTdllTYPE) GetProcAddress(RefpropdllInstance,"DDDTdll");
	DEFLSHdll = (fp_DEFLSHdllTYPE) GetProcAddress(RefpropdllInstance,"DEFLSHdll");
	DHD1dll = (fp_DHD1dllTYPE) GetProcAddress(RefpropdllInstance,"DHD1dll");
	DHFLSHdll = (fp_DHFLSHdllTYPE) GetProcAddress(RefpropdllInstance,"DHFLSHdll");
	DIELECdll = (fp_DIELECdllTYPE) GetProcAddress(RefpropdllInstance,"DIELECdll");
	DOTFILLdll = (fp_DOTFILLdllTYPE) GetProcAddress(RefpropdllInstance,"DOTFILLdll");
	DPDD2dll = (fp_DPDD2dllTYPE) GetProcAddress(RefpropdllInstance,"DPDD2dll");
	DPDDKdll = (fp_DPDDKdllTYPE) GetProcAddress(RefpropdllInstance,"DPDDKdll");
	DPDDdll = (fp_DPDDdllTYPE) GetProcAddress(RefpropdllInstance,"DPDDdll");
	DPDTKdll = (fp_DPDTKdllTYPE) GetProcAddress(RefpropdllInstance,"DPDTKdll");
	DPDTdll = (fp_DPDTdllTYPE) GetProcAddress(RefpropdllInstance,"DPDTdll");
	DPTSATKdll = (fp_DPTSATKdllTYPE) GetProcAddress(RefpropdllInstance,"DPTSATKdll");
	DSFLSHdll = (fp_DSFLSHdllTYPE) GetProcAddress(RefpropdllInstance,"DSFLSHdll");
	ENTHALdll = (fp_ENTHALdllTYPE) GetProcAddress(RefpropdllInstance,"ENTHALdll"); //**
	ENTROdll = (fp_ENTROdllTYPE) GetProcAddress(RefpropdllInstance,"ENTROdll");
	ESFLSHdll = (fp_ESFLSHdllTYPE) GetProcAddress(RefpropdllInstance,"ESFLSHdll");
	FGCTYdll = (fp_FGCTYdllTYPE) GetProcAddress(RefpropdllInstance,"FGCTYdll");
	FPVdll = (fp_FPVdllTYPE) GetProcAddress(RefpropdllInstance,"FPVdll");
	GERG04dll = (fp_GERG04dllTYPE) GetProcAddress(RefpropdllInstance,"GERG04dll");
	GETFIJdll = (fp_GETFIJdllTYPE) GetProcAddress(RefpropdllInstance,"GETFIJdll");
	GETKTVdll = (fp_GETKTVdllTYPE) GetProcAddress(RefpropdllInstance,"GETKTVdll");
	GIBBSdll = (fp_GIBBSdllTYPE) GetProcAddress(RefpropdllInstance,"GIBBSdll");
	HSFLSHdll = (fp_HSFLSHdllTYPE) GetProcAddress(RefpropdllInstance,"HSFLSHdll");
	INFOdll = (fp_INFOdllTYPE) GetProcAddress(RefpropdllInstance,"INFOdll");
	LIMITKdll = (fp_LIMITKdllTYPE) GetProcAddress(RefpropdllInstance,"LIMITKdll");
	LIMITSdll = (fp_LIMITSdllTYPE) GetProcAddress(RefpropdllInstance,"LIMITSdll");
	LIMITXdll = (fp_LIMITXdllTYPE) GetProcAddress(RefpropdllInstance,"LIMITXdll");
	MELTPdll = (fp_MELTPdllTYPE) GetProcAddress(RefpropdllInstance,"MELTPdll");
	MELTTdll = (fp_MELTTdllTYPE) GetProcAddress(RefpropdllInstance,"MELTTdll");
	MLTH2Odll = (fp_MLTH2OdllTYPE) GetProcAddress(RefpropdllInstance,"MLTH2Odll");
	NAMEdll = (fp_NAMEdllTYPE) GetProcAddress(RefpropdllInstance,"NAMEdll");
	PDFL1dll = (fp_PDFL1dllTYPE) GetProcAddress(RefpropdllInstance,"PDFL1dll");
	PDFLSHdll = (fp_PDFLSHdllTYPE) GetProcAddress(RefpropdllInstance,"PDFLSHdll");
	PEFLSHdll = (fp_PEFLSHdllTYPE) GetProcAddress(RefpropdllInstance,"PEFLSHdll");
	PHFL1dll = (fp_PHFL1dllTYPE) GetProcAddress(RefpropdllInstance,"PHFL1dll");
	PHFLSHdll = (fp_PHFLSHdllTYPE) GetProcAddress(RefpropdllInstance,"PHFLSHdll");
	PQFLSHdll = (fp_PQFLSHdllTYPE) GetProcAddress(RefpropdllInstance,"PQFLSHdll");
	PREOSdll = (fp_PREOSdllTYPE) GetProcAddress(RefpropdllInstance,"PREOSdll");
	PRESSdll = (fp_PRESSdllTYPE) GetProcAddress(RefpropdllInstance,"PRESSdll");
	PSFL1dll = (fp_PSFL1dllTYPE) GetProcAddress(RefpropdllInstance,"PSFL1dll");
	PSFLSHdll = (fp_PSFLSHdllTYPE) GetProcAddress(RefpropdllInstance,"PSFLSHdll");
	PUREFLDdll = (fp_PUREFLDdllTYPE) GetProcAddress(RefpropdllInstance,"PUREFLDdll");
	QMASSdll = (fp_QMASSdllTYPE) GetProcAddress(RefpropdllInstance,"QMASSdll");
	QMOLEdll = (fp_QMOLEdllTYPE) GetProcAddress(RefpropdllInstance,"QMOLEdll");
	SATDdll = (fp_SATDdllTYPE) GetProcAddress(RefpropdllInstance,"SATDdll");
	SATEdll = (fp_SATEdllTYPE) GetProcAddress(RefpropdllInstance,"SATEdll");
	SATHdll = (fp_SATHdllTYPE) GetProcAddress(RefpropdllInstance,"SATHdll");
	SATPdll = (fp_SATPdllTYPE) GetProcAddress(RefpropdllInstance,"SATPdll");
	SATSdll = (fp_SATSdllTYPE) GetProcAddress(RefpropdllInstance,"SATSdll");
	SATTdll = (fp_SATTdllTYPE) GetProcAddress(RefpropdllInstance,"SATTdll");
	SETAGAdll = (fp_SETAGAdllTYPE) GetProcAddress(RefpropdllInstance,"SETAGAdll");
	SETKTVdll = (fp_SETKTVdllTYPE) GetProcAddress(RefpropdllInstance,"SETKTVdll");
	SETMIXdll = (fp_SETMIXdllTYPE) GetProcAddress(RefpropdllInstance,"SETMIXdll");
	SETMODdll = (fp_SETMODdllTYPE) GetProcAddress(RefpropdllInstance,"SETMODdll");
	SETREFdll = (fp_SETREFdllTYPE) GetProcAddress(RefpropdllInstance,"SETREFdll");
	SETUPdll = (fp_SETUPdllTYPE) GetProcAddress(RefpropdllInstance,"SETUPdll");
	SPECGRdll = (fp_SPECGRdllTYPE) GetProcAddress(RefpropdllInstance,"SPECGRdll");
	SUBLPdll = (fp_SUBLPdllTYPE) GetProcAddress(RefpropdllInstance,"SUBLPdll");
	SUBLTdll = (fp_SUBLTdllTYPE) GetProcAddress(RefpropdllInstance,"SUBLTdll");
	SURFTdll = (fp_SURFTdllTYPE) GetProcAddress(RefpropdllInstance,"SURFTdll");
	SURTENdll = (fp_SURTENdllTYPE) GetProcAddress(RefpropdllInstance,"SURTENdll");
	TDFLSHdll = (fp_TDFLSHdllTYPE) GetProcAddress(RefpropdllInstance,"TDFLSHdll");
	TEFLSHdll = (fp_TEFLSHdllTYPE) GetProcAddress(RefpropdllInstance,"TEFLSHdll");
	THERM0dll = (fp_THERM0dllTYPE) GetProcAddress(RefpropdllInstance,"THERM0dll");
	THERM2dll = (fp_THERM2dllTYPE) GetProcAddress(RefpropdllInstance,"THERM2dll");
	THERM3dll = (fp_THERM3dllTYPE) GetProcAddress(RefpropdllInstance,"THERM3dll");
	THERMdll = (fp_THERMdllTYPE) GetProcAddress(RefpropdllInstance,"THERMdll");
	THFLSHdll = (fp_THFLSHdllTYPE) GetProcAddress(RefpropdllInstance,"THFLSHdll");
	TPFLSHdll = (fp_TPFLSHdllTYPE) GetProcAddress(RefpropdllInstance,"TPFLSHdll");
	TPRHOdll = (fp_TPRHOdllTYPE) GetProcAddress(RefpropdllInstance,"TPRHOdll");
	TQFLSHdll = (fp_TQFLSHdllTYPE) GetProcAddress(RefpropdllInstance,"TQFLSHdll");
	TRNPRPdll = (fp_TRNPRPdllTYPE) GetProcAddress(RefpropdllInstance,"TRNPRPdll");
	TSFLSHdll = (fp_TSFLSHdllTYPE) GetProcAddress(RefpropdllInstance,"TSFLSHdll");
	VIRBdll = (fp_VIRBdllTYPE) GetProcAddress(RefpropdllInstance,"VIRBdll");
	VIRCdll = (fp_VIRCdllTYPE) GetProcAddress(RefpropdllInstance,"VIRCdll");
	WMOLdll = (fp_WMOLdllTYPE) GetProcAddress(RefpropdllInstance,"WMOLdll");
	XMASSdll = (fp_XMASSdllTYPE) GetProcAddress(RefpropdllInstance,"XMASSdll");
	XMOLEdll = (fp_XMOLEdllTYPE) GetProcAddress(RefpropdllInstance,"XMOLEdll");
}


double *properties(double t, double d)
{
  double t_const=t,d_const=d;
  double x[ncmax],xliq[ncmax],xvap[ncmax],f[ncmax];

  long i,ierr=0;
  char hf[refpropcharlength*ncmax], hrf[lengthofreference+1],
      herr[errormessagelength+1], hfmix[refpropcharlength+1];

	double wm,ttp,tnbp,tc,pc,dc,zc,acf,dip,rgas;
	long info_index=1;

	double p,dl,dv;
	long j=1;
	double q=0.0,e=0.0,h=0.0,s=0.0,cv=0.0,cp=0.0,w=0.0,b=0.0,c=0.0,
		  dpdrho,d2pdd2,dpdt,dddt,dhdt_d,dhdt_p,dhdp_t,dhdp_d,
		  sigma,dhdd_t,dhdd_p,eta,tcx,pp,tt,hjt,h1,dd,Zz,
		  a,g,xkappa,beta,dPdD,d2PdD2,dPdT,dDdT,dDdP,d2PdT2,d2PdTD,spare3,spare4;
  long tmp_int=0;
  long kr=1;

  Linkdll();

  //...Now use the functions.

  //...Refprop variables that need to be defined
  //
  //...nc = Number of components in the mixture
  //...x[NumberOfComponentsInMixtures] = Mole fraction of each component
  //...ierr =  An integer flag defining an error
  //...hf[] = a character array defining the fluids in a mixture
  //...hrf[] = a character array denoting the reference state
  //...herr[] = a character array for storing a string - Error message
  //...hfmix[] a character array defining the path to the mixture file


  //...Exlicitely set the fluid file PATH

  char *FLD_PATH;
  FLD_PATH = "F:\\refprop_dll_file\\fluids\\";
  strcpy(hf,FLD_PATH);
  strcpy(hfmix,FLD_PATH);

  //...initialize the program and set the pure fluid component name

  i=1;
  strcat(hf,"N2O.FLD");
  strcat(hfmix,"hmx.bnc");
  strcpy(hrf,"DEF");
  strcpy(herr,"Ok");

  //...For a mixture, use the following setup instead of the lines above.
  //...Use "|" as the file name delimiter for mixtures.
/*
	i=3;
	strcat(hf,"nitrogen.fld");
	strcat(hf,"|argon.fld");
	strcat(hf,"|oxygen.fld");
	strcpy(hfmix,"hmx.bnc");
	strcpy(hrf,"DEF");
	strcpy(herr,"Ok");
	x[0]=0.7812;
	x[1]=0.0092;
	x[2]=0.2096;
*/

  //...Call SETUPdll to initialize the program.
	SETUPdll(&i, hf, hfmix, hrf, &ierr, herr,
			refpropcharlength*ncmax,refpropcharlength,
			lengthofreference,errormessagelength);
  //...long ,char*,char*,char*,long ,char*,long ,long ,long ,long

	if (ierr != 0) printf("%s\n",herr);

	//...Call INFOdll to get the fluid constant of the component.
	INFOdll(&info_index,&wm,&ttp,&tnbp,&tc,&pc,&dc,&zc,&acf,&dip,&rgas);

	//...Get saturation properties given t,x; for i=1: x is liquid phase
  //.....                                   for i=2: x is vapor phase

  double psat1,psat2,tsat,dl1,dl2,dv1,dv2;
	i=1;
  SATTdll(&t,x,&i,&psat1,&dl1,&dv1,xliq,xvap,&ierr,herr,errormessagelength);
  i=2;
  SATTdll(&t,x,&i,&psat2,&dl2,&dv2,xliq,xvap,&ierr,herr,errormessagelength);
  //...In fact, along the saturation line, for both liquid and vapor phase, t & p are the same.

  //...printf("%s",hf)_legacy used to debug;
  //...solve properties from T,rho
  //..."Zz" means compression factor. In THERM2dll(), density is d_vapor
  dl1=dl1*wm;
  dl2=dl2*wm;
  dv1=dv1*wm;
  dv2=dv2*wm;
  //...for initializer

  d=d_const/wm;
  THERM2dll(&t,&dv,x,&p,&e,&h,&s,&cv,&cp,&w,&Zz,&hjt,&a,&g,&xkappa,&beta,&dPdD,&d2PdD2,&dPdT,
            &dDdT,&dDdP,&d2PdT2,&d2PdTD,&spare3,&spare4);
  THERMdll(&t,&d,x,&p,&e,&h,&s,&cv,&cp,&w,&hjt);
  SATPdll(&p,x,&i,&tsat,&dl,&dv,xliq,xvap,&ierr,herr,errormessagelength);

  //...solve viscosity (eta) and thermal conductivity (tcx)
  TRNPRPdll (&t,&d,x,&eta,&tcx,&ierr,herr,errormessagelength);

  //...Calculate derivatives of enthalpy with respect to T, P, and D
  DHD1dll(&t,&d,x,&dhdt_d,&dhdt_p,&dhdd_t,&dhdd_p,&dhdp_t,&dhdp_d);

  DPDTdll(&t_const,&d_const,x,&dpdt);
  DDDTdll(&t_const,&d_const,x,&dddt);
  DPDDdll(&t_const,&d_const,x,&dpdrho);

  //...use malloc() to set array
  d=d*wm;
  int num=23;
  double *output;
  output=(double*)malloc(sizeof(double)*num);
  output[0]=p*1e3;
  output[1]=h/wm*1e3;
  output[2]=e/wm*1e3;
  output[3]=psat1*1e3;
  output[4]=psat2*1e3;
  output[5]=Zz;
  output[6]=eta;
  output[7]=tcx;
  output[8]=cp/wm*1e3;
  output[9]=tsat;

  output[10]=dl1;
  output[11]=dl2;
  output[12]=dv1;
  output[13]=dv2;
  output[14]=wm;

  output[15]=dhdt_d/wm*1e3;
  output[16]=dhdd_t/wm/wm*1e3;
  output[17]=dDdT*wm;
  output[18]=dPdT*1e3;
  output[19]=dpdrho*1e3/wm;

  double dudT, dudD, u;
  dudT=output[15]-(1/d*output[18]-output[0]/d/d*output[17]);
  dudD=output[16]-(1/d*output[19]-output[0]/d/d);
  u=output[1]-output[0]/d;

  output[20]=dudT;
  output[21]=dudD;
  output[22]=u;

	return output;
	//...return parameter array
}


//...get pressure(SIunit=Pa)
double Get_pressure(double t, double d)
{
  double *p;
  p=properties(t,d);
  return p[0];
}

//...get enthalpy(SIunit=J/kg)
double Get_enthalpy(double t, double d)
{
  double *h;
  h=properties(t,d);
  return h[1];
}

//...get internal energy(SIunit=J/kg)
double Get_IntEnergy(double t, double d)
{
  double *u;
  u=properties(t,d);
  return u[2];
}

//...get saturation pressure(SIunit=Pa)
double Get_Psat1(double t, double d)
{
  double *Psat;
  Psat=properties(t,d);
  return Psat[3];
}

//...get saturation pressure(SIunit=Pa)
double Get_Psat2(double t, double d)
{
  double *Psat;
  Psat=properties(t,d);
  return Psat[4];
}

//...get compression factor(SIunit="1")
double Get_Z(double t, double d)
{
  double *Z;
  Z=properties(t,d);
  return Z[5];
}

//...get viscosity(nonSIunit="miuPa.s")
double Get_viscosity(double t, double d)
{
  double *vis;
  vis=properties(t,d);
  return vis[6];
}

//...get thermal conductivity(SIunit="W/(m.K)")
double Get_thermalcond(double t, double d)
{
  double *tcx;
  tcx=properties(t,d);
  return tcx[7];
}

//...get cp(SIunit="J/(kg.K)")
double Get_cp(double t, double d)
{
  double *c;
  c=properties(t,d);
  return c[8];
}

//...get saturation temperature(SIunit="K")
double Get_tsat(double t, double d)
{
  double *tsat;
  tsat=properties(t,d);
  return tsat[9];
}

//...get initial liquid density1(SIunit="kg/m3")
double Get_dl1(double t, double d)
{
  double *dl;
  dl=properties(t,d);
  return dl[10];
}

//...get initial liquid density2(SIunit="kg/m3")
double Get_dl2(double t, double d)
{
  double *dl;
  dl=properties(t,d);
  return dl[11];
}

//...get initial vapor density1(SIunit="kg/m3")
double Get_dv1(double t, double d)
{
  double *dv;
  dv=properties(t,d);
  return dv[12];
}

//...get initial vapor density2(SIunit="kg/m3")
double Get_dv2(double t, double d)
{
  double *dv;
  dv=properties(t,d);
  return dv[13];
}

//...4 functions for s1 & s2
double Get_m_vap(double tl, double dl, double hlv)
{
  double *s, m_vap, hls, Emp=2.1e4, tsat, Als, D=Diam,
      g=9.8, u, k, cp, nls=1/3, Cls=0.15, l;

  s=properties(tl,dl);
  tsat=s[9];
  s=properties((tl+tsat)/2,dl);

  u=s[6];
  k=s[7];
  cp=s[8];

  l=D;

  Als=pi/4*D*D;
  hls=Cls*pow(l*l*l*dl*dl*g*2/(tl+tsat)/u*cp/k*fabs(tl-tsat),nls)*k/l;

  m_vap=Emp*hls*Als*(tl-tsat)/hlv*1000;
  return m_vap;
}

double Get_m_cond(double tg, double dg, double hg)
{
  double *s, m_cond, Zg, P, Psat, dtime=0.001, wm, Vg, D=Diam;
  Vg=pi/4*D*D*hg;
  s=properties(tg,dg);

  P=s[0];
  Psat=s[3];
  Zg=s[5];
  wm=s[14];

  if (P>Psat)
    m_cond=(P-Psat)*Vg/Zg/Ru*wm/tg/dtime;
  else
    m_cond=0;

  return m_cond;
}

double Get_Qin_g(double tg, double dg, double hg)
{
  double *s, Qgin, tw=278, Agw, hgw, ngw=2/5, Cgw=0.021, l,
      g=9.8, D=Diam, u, k, cp, tsat;
  s=properties(tg,dg);
  tsat=s[9];
  s=properties((tg+tw)/2,dg);

  u=s[6];
  k=s[7];
  cp=s[8];
  l=hg;

  Agw=pi*D*l;
  hgw=Cgw*pow(l*l*l*dg*dg*g*2/(tg+tsat)/u*cp/k*fabs(tg-tw),ngw)*k/l;

  Qgin=hgw*Agw*(tg-tw);

  return Qgin;
}

double Get_Qin_l(double tl, double dl, double hg)
{
  double *s, Qlin, tw=278, Alw, hlw, nlw=2/5, Clw=0.021, l,
      g=9.8, D=Diam, u, k, cp, tsat;
  s=properties(tl,dl);
  tsat=s[9];
  s=properties((tl+tw)/2,dl);

  u=s[6];
  k=s[7];
  cp=s[8];

  l=height-hg;

  Alw=pi*D*l;
  hlw=Clw*pow(l*l*l*dl*dl*g*2/(tl+tsat)/u*cp/k*fabs(tl-tw),nlw)*k/l;

  Qlin=hlw*Alw*(tl-tw);

  return Qlin;
}

//...get molar mass(unit="g/mol")
double Get_wm(double t, double d)
{
  double *w,wm;
  w=properties(t,d);

  wm=w[14];

  return wm;
}

//...get derivatives
double Get_dhdt(double t, double d)
{
  double *dh;
  dh=properties(t,d);
  return dh[15];
}

double Get_dhdd(double t, double d)
{
  double *dh;
  dh=properties(t,d);
  return dh[16];
}

double Get_dDdT(double t, double d)
{
  double *dD;
  dD=properties(t,d);
  return dD[17];
}

double Get_dPdT(double t, double d)
{
  double *dP;
  dP=properties(t,d);
  return dP[18];
}

double Get_dPdD(double t, double d)
{
  double *dP;
  dP=properties(t,d);
  return dP[19];
}

double Get_dudT(double t, double d)
{
  double *du;
  du=properties(t,d);
  return du[20];
}

double Get_dudD(double t, double d)
{
  double *du;
  du=properties(t,d);
  return du[21];
}

double Get_u(double t, double d)
{
  double *u;
  u=properties(t,d);
  return u[22];
}


//...main() function used to debug
int main()
{
  double temperature=288,density=100;
  double pressure,enthalpy,IntEnergy,Psat1,Psat2,Z,vis,thermalcond,cp,tsat;
  double dl1,dl2,dv1,dv2;
  double Qgw,Qlw,hg=0.2;
  double mcond,mvap,hlv=189.13*1e3;
  double wm;
  double dhdt,dhdd,dDdT,dPdT,dPdD,dudT,dudD,u;

  pressure=Get_pressure(temperature,density)*1e-6;
  enthalpy=Get_enthalpy(temperature,density);
  IntEnergy=Get_IntEnergy(temperature,density);
  Psat1=Get_Psat1(temperature,density)*1e-6;
  Psat2=Get_Psat2(temperature,density)*1e-6;
  Z=Get_Z(temperature,density);
  vis=Get_viscosity(temperature,density);
  thermalcond=Get_thermalcond(temperature,density);
  cp=Get_cp(temperature,density);
  tsat=Get_tsat(temperature,density);

  dl1=Get_dl1(temperature,density);
  dl2=Get_dl2(temperature,density);
  dv1=Get_dv1(temperature,density);
  dv2=Get_dv2(temperature,density);

  Qgw=Get_Qin_g(temperature,density,hg);
  Qlw=Get_Qin_l(temperature,density,hg);

  mvap=Get_m_vap(temperature,dv1,hlv);
  mcond=Get_m_cond(temperature,dl1,hg);

  wm=Get_wm(temperature,density);

  dhdt=Get_dhdt(temperature,density);
  dhdd=Get_dhdd(temperature,density);
  dDdT=Get_dDdT(temperature,density);
  dPdT=Get_dPdT(temperature,density);
  dPdD=Get_dPdD(temperature,density);
  dudT=Get_dudT(temperature,density);
  dudD=Get_dudD(temperature,density);

  u=Get_u(temperature,density);

  printf("N2O_pressure=%lf(unit=MPa)\n",pressure);
	printf("N2O_enthalpy=%lf(unit=kJ/kg)\n",enthalpy);
	printf("N2O_IntEnergy=%lf(unit=kJ/kg)\n",IntEnergy);
	printf("Psat1=%lf(unit=MPa)\n",Psat1);
	printf("Psat2=%lf(unit=MPa)\n",Psat1);
	printf("Z=%lf(unit=1)\n",Z);
	printf("viscosity=%lf(unit=miuPa.s)\n",vis);
	printf("thermalconductivity=%lf(unit=W/(m.K))\n",thermalcond);
	printf("cp=%lf(unit=kJ/(kg.K))\n",cp);
	printf("tsat=%lf(unit=K)\n",tsat);

  printf("dl1=%lf(unit=kg/m3)\n",dl1);
  printf("dl2=%lf(unit=kg/m3)\n",dl2);
  printf("dv1=%lf(unit=kg/m3)\n",dv1);
  printf("dv2=%lf(unit=kg/m3)\n",dv2);

  printf("Qgw=%lf(unit=W)\n",Qgw);
  printf("Qlw=%lf(unit=W)\n",Qlw);

  printf("mvap=%lf(unit=kg/s)\n",mvap);
  printf("mcond=%lf(unit=kg/s)\n",mcond);

  printf("wm=%lf(unit=g/mol)\n",wm);

  printf("dhdt=%lf(unit=J/kg/K)\n",dhdt);
  printf("dhdd=%lf(unit=J/kg/(kg.m3))\n",dhdd);
  printf("dDdT=%lf(unit=kg/(K.m3))\n",dDdT);
  printf("dPdT=%lf(unit=P/K)\n",dPdT);
  printf("dPdD=%lf(unit=P/(kg.m3))\n",dPdD);
  printf("dudT=%lf(unit=J/kg/K)\n",dudT);
  printf("dudD=%lf(unit=J/kg/(kg.m3))\n",dudD);

  printf("u=%lf(unit=J/kg)\n",u);

  return 0;
}








