/***********
 * Description:
 * Calculate thermodynamic properties and partial derivative of N2O
 *
 * Author:
 * Wangjr @ASRST
 *
 * References:
 * [1] Lemmon E W .Short Fundamental Equations of State for 20 Industrial Fluids[J].Journal of Chemical & Engineering Data, 2006, 51(3):p��gs. 785-850.
 *     DOI:10.1021/je050186n.
 * [2] Dyer J , Zilliac G , Sadhwani A ,et al.Modeling Feed System Flow Physics for Self-Pressurizing Propellants[C]//43rd AIAA/ASME/SAE/ASEE Joint Propulsion Conference & Exhibit.2007.
 *     DOI:10.2514/6.2007-5702.
 ************/


#include "math.h"
#include "stdio.h"
#include "stdlib.h"

#define rho_acc 1e-6

#define R 8.314472e3/44.0128
#define p_c 7.245
#define T_c 309.52
#define rho_c 452.0115

#define n1 0.88045
#define n2 -2.4235
#define n3 0.38237
#define n4 0.068917
#define n5 0.00020367
#define n6 0.13122
#define n7 0.46032
#define n8 -0.0036985
#define n9 -0.23263
#define n10 -0.00042859
#define n11 -0.04281
#define n12 -0.023038

#define c0 3.5
#define a1 -4.4262736272
#define a2 4.3120175243
#define v1 2.1769
#define u1 879.0
#define v2 1.6145
#define u2 2372.0
#define v3 0.48393
#define u3 5447.0

/*
double a_0(double x, double y);
double a_r(double x, double y);
double a0_y(double x, double y);
double a0_yy(double x, double y);
double ar_x(double x, double y);
double ar_y(double x, double y);
double ar_xx(double x, double y);
double ar_yy(double x, double y);
double ar_xy(double x, double y);
double ar_x3(double x, double y);
double h(double rho, double T);
double s(double rho, double T);
double g(double rho, double T);
double cv(double rho, double T);
double cp(double rho, double T);
double w2(double rho, double T);
double p_rho(double rho, double T);
double p_rho2(double rho, double T);
double p_T(double rho, double T);
double p_sat(double T);
double rho(double T, double p);
double dudT(double x, double y);
double dudD(double x, double y);
*/
/*
// \s(?=\*)|(?<=\*)\s
// ��������Helmholtz��
double a_0(double x, double y)
{
    return  a1 + a2*y + log(x) + (c0 - 1)*log(y) +
            v1*log(1 - exp(-u1*y/T_c)) +
            v2*log(1 - exp(-u2*y/T_c)) +
            v3*log(1 - exp(-u3*y/T_c));
}

// ��ʵ����Helmholtz��ƫ��
double a_r(double x, double y)
{
    return  n1*x*pow(y, 0.25) + n2*x*pow(y, 1.25) +
            n3*x*pow(y, 1.5) + n4*pow(x, 3)*pow(y, 0.25) +
            n5*pow(x, 7)*pow(y, 0.875) +
            n6*x*pow(y, 2.375)*exp(-x) +
            n7*pow(x, 2)*pow(y, 2)*exp(-x) +
            n8*pow(x, 5)*pow(y, 2.125)*exp(-x) +
            n9*x*pow(y, 3.5)*exp(-x*x) +
            n10*x*pow(y, 6.5)*exp(-x*x) +
            n11*pow(x, 4)*pow(y, 4.75)*exp(-x*x) +
            n12*pow(x, 2)*pow(y, 12.5)*exp(-x*x*x);
}

// Helmholtz��ƫ����
double a0_y(double x, double y)
{
    return  a2 + (c0 - 1)/y -
           (u1*v1*exp(-(u1*y)/T_c))/(T_c*(exp(-(u1*y)/T_c) - 1)) -
           (u2*v2*exp(-(u2*y)/T_c))/(T_c*(exp(-(u2*y)/T_c) - 1)) -
           (u3*v3*exp(-(u3*y)/T_c))/(T_c*(exp(-(u3*y)/T_c) - 1));
}

double a0_yy(double x, double y)
{
    return (u1*u1*v1*exp(-(u1*y)/T_c))/(T_c*T_c*(exp(-(u1*y)/T_c) - 1)) - (c0 - 1)/(y*y) - (u1*u1*v1*exp(-(2*u1*y)/T_c))/(T_c*T_c*(exp(-(u1*y)/T_c) - 1)*(exp(-(u1*y)/T_c) - 1)) +
           (u2*u2*v2*exp(-(u2*y)/T_c))/(T_c*T_c*(exp(-(u2*y)/T_c) - 1)) - (u2*u2*v2*exp(-(2*u2*y)/T_c))/(T_c*T_c*(exp(-(u2*y)/T_c) - 1)*(exp(-(u2*y)/T_c) - 1)) +
           (u3*u3*v3*exp(-(u3*y)/T_c))/(T_c*T_c*(exp(-(u3*y)/T_c) - 1)) - (u3*u3*v3*exp(-(2*u3*y)/T_c))/(T_c*T_c*(exp(-(u3*y)/T_c) - 1)*(exp(-(u3*y)/T_c) - 1));

}

double ar_x(double x, double y)
{
    return  n1*pow(y, 1.0/4.0) + n3*pow(y, 3.0/2.0) + n2*pow(y, 5.0/4.0) + n9*pow(y, 7.0/2.0)*exp(-x*x) +
            n10*pow(y, 13.0/2.0)*exp(-x*x) + 3*n4*x*x*pow(y, 1.0/4.0) + 7*n5*pow(x, 6.0)*pow(y, 7.0/8.0) +
            n6*pow(y, 19.0/8.0)*exp(-x) - 2*n9*x*x*pow(y, 7.0/2.0)*exp(-x*x) - 2*n10*x*x*pow(y, 13.0/2.0)*exp(-x*x) +
            4*n11*x*x*x*pow(y, 19.0/4.0)*exp(-x*x) - 2*n11*pow(x, 5.0)*pow(y, 19.0/4.0)*exp(-x*x) - 3*n12*pow(x, 4.0)*pow(y, 25.0/2.0)*exp(-x*x*x) +
            2*n7*x*pow(y, 2.0)*exp(-x) - n6*x*pow(y, 19.0/8.0)*exp(-x) - n7*x*x*pow(y, 2.0)*exp(-x) + 5*n8*pow(x, 4.0)*pow(y, 17.0/8.0)*exp(-x) -
            n8*pow(x, 5.0)*pow(y, 17.0/8.0)*exp(-x) + 2*n12*x*pow(y, 25.0/2.0)*exp(-x*x*x);
}

double ar_y(double x, double y)
{
    return (3*n3*x*pow(y, 1.0/2.0))/2 + (5*n2*x*pow(y, 1.0/4.0))/4 + (n1*x)/(4*pow(y, 3.0/4.0)) + (n4*x*x*x)/(4*pow(y, 3.0/4.0)) +
           (7*n5*x*x*x*x*x*x)/(8*pow(y, 1.0/8.0)) + (19*n11*x*x*x*x*pow(y, 15.0/4.0)*exp(-x*x))/4 + (25*n12*x*x*pow(y, 23.0/2.0)*exp(-x*x*x))/2 +
            2*n7*x*x*y*exp(-x) + (19*n6*x*pow(y, 11.0/8.0)*exp(-x))/8 + (7*n9*x*pow(y, 5.0/2.0)*exp(-x*x))/2 + (13*n10*x*pow(y, 11.0/2.0)*exp(-x*x))/2 +
           (17*n8*x*x*x*x*x*pow(y, 9.0/8.0)*exp(-x))/8;
}

double ar_xx(double x, double y)
{
    return  6*n4*x*pow(y, 1.0/4.0) + 2*n12*pow(y, 25.0/2.0)*exp(-x*x*x) + 42*n5*pow(x, 5.0)*pow(y, 7.0/8.0) + 2*n7*pow(y, 2.0)*exp(-x) -
            2*n6*pow(y, 19.0/8.0)*exp(-x) + 4*n9*pow(x, 3.0)*pow(y, 7.0/2.0)*exp(-x*x) + 4*n10*pow(x, 3.0)*pow(y, 13.0/2.0)*exp(-x*x) +
            12*n11*pow(x, 2.0)*pow(y, 19.0/4.0)*exp(-x*x) - 18*n11*pow(x, 4.0)*pow(y, 19.0/4.0)*exp(-x*x) + 4*n11*pow(x, 6.0)*pow(y, 19.0/4.0)*exp(-x*x) -
            18*n12*pow(x, 3.0)*pow(y, 25.0/2.0)*exp(-x*x*x) + 9*n12*pow(x, 6.0)*pow(y, 25.0/2.0)*exp(-x*x*x) - 4*n7*x*pow(y, 2.0)*exp(-x) +
            n6*x*pow(y, 19.0/8.0)*exp(-x) + n7*pow(x, 2.0)*pow(y, 2.0)*exp(-x) - 6*n9*x*pow(y, 7.0/2.0)*exp(-x*x) - 6*n10*x*pow(y, 13.0/2.0)*exp(-x*x) +
            20*n8*pow(x, 3.0)*pow(y, 17.0/8.0)*exp(-x) - 10*n8*pow(x, 4.0)*pow(y, 17.0/8.0)*exp(-x) + n8*pow(x, 5.0)*pow(y, 17.0/8.0)*exp(-x);
}

double ar_yy(double x, double y)
{
    return (3*n3*x)/(4*pow(y, 0.5)) + (5*n2*x)/(16*pow(y, 0.75)) - (3*n1*x)/(16*pow(y, 1.75)) - (3*n4*x*x*x)/(16*pow(y, 1.75)) - (7*n5*x*x*x*x*x*x)/(64*pow(y, 1.125)) +
            2*n7*x*x*exp(-x) + (285*n11*x*x*x*x*pow(y, 2.75)*exp(-x*x))/16 + (575*n12*x*x*pow(y, 10.5)*exp(-x*x*x))/4 + (209*n6*x*pow(y, 0.375)*exp(-x))/64 +
           (35*n9*x*pow(y, 1.5)*exp(-x*x))/4 + (153*n8*x*x*x*x*pow(y, 0.125)*exp(-x))/64 + (143*n10*x*pow(y, 4.5)*exp(-x*x))/4;
}

double ar_xy(double x, double y)
{
    return (3*n3*pow(y, 1.0/2.0))/2 + (5*n2*pow(y, 1.0/4.0))/4 + n1/(4*pow(y, 3.0/4.0)) + (7*n9*pow(y, 5.0/2.0)*exp(-x*x))/2 + (13*n10*pow(y, 11.0/2.0)*exp(-x*x))/2 +
           (3*n4*x*x)/(4*pow(y, 3.0/4.0)) + (49*n5*pow(x, 6.0))/(8*pow(y, 1.0/8.0)) + (19*n6*pow(y, 11.0/8.0)*exp(-x))/8 - 7*n9*x*x*pow(y, 5.0/2.0)*exp(-x*x) -
            13*n10*x*x*pow(y, 11.0/2.0)*exp(-x*x) + 19*n11*x*x*x*pow(y, 15.0/4.0)*exp(-x*x) - (19*n11*pow(x, 5.0)*pow(y, 15.0/4.0)*exp(-x*x))/2 -
           (75*n12*pow(x, 4.0)*pow(y, 23.0/2.0)*exp(-x*x*x))/2 - 2*n7*x*x*y*exp(-x) - (19*n6*x*pow(y, 11.0/8.0)*exp(-x))/8 + (85*n8*pow(x, 4.0)*pow(y, 9.0/8.0)*exp(-x))/8 -
           (17*n8*pow(x, 5.0)*pow(y, 9.0/8.0)*exp(-x))/8 + 25*n12*x*pow(y, 23.0/2.0)*exp(-x*x*x) + 4*n7*x*y*exp(-x);
}

double ar_x3(double x, double y)
{
    return  6*n4*pow(y, 1.0/4.0) - 6*n9*pow(y, 7.0/2.0)*exp(-x*x) - 6*n10*pow(y, 13.0/2.0)*exp(-x*x) + 210*n5*pow(x, 4.0)*pow(y, 7.0/8.0) -
            6*n7*pow(y, 2.0)*exp(-x) + 3*n6*pow(y, 19.0/8.0)*exp(-x) + 24*n9*pow(x, 2.0)*pow(y, 7.0/2.0)*exp(-x*x) - 8*n9*pow(x, 4.0)*pow(y, 7.0/2.0)*exp(-x*x) +
            24*n10*pow(x, 2.0)*pow(y, 13.0/2.0)*exp(-x*x) - 8*n10*pow(x, 4.0)*pow(y, 13.0/2.0)*exp(-x*x) - 96*n11*pow(x, 3.0)*pow(y, 19.0/4.0)*exp(-x*x) +
            60*n11*pow(x, 5.0)*pow(y, 19.0/4.0)*exp(-x*x) - 8*n11*pow(x, 7.0)*pow(y, 19.0/4.0)*exp(-x*x) - 60*n12*pow(x, 2.0)*pow(y, 25.0/2.0)*exp(-x*x*x) +
            108*n12*pow(x, 5.0)*pow(y, 25.0/2.0)*exp(-x*x*x) - 27*n12*pow(x, 8.0)*pow(y, 25.0/2.0)*exp(-x*x*x) + 6*n7*x*pow(y, 2.0)*exp(-x) - n6*x*pow(y, 19.0/8.0)*exp(-x) -
            n7*pow(x, 2.0)*pow(y, 2.0)*exp(-x) + 60*n8*pow(x, 2.0)*pow(y, 17.0/8.0)*exp(-x) - 60*n8*pow(x, 3.0)*pow(y, 17.0/8.0)*exp(-x) + 24*n11*x*pow(y, 19.0/4.0)*exp(-x*x) +
            15*n8*pow(x, 4.0)*pow(y, 17.0/8.0)*exp(-x) - n8*pow(x, 5.0)*pow(y, 17.0/8.0)*exp(-x);
}


// ����ѧ����
// ѹ������
double Z(double rho, double T)
{
    double x = rho/rho_c, y = T_c/T;
    return 1 + x*ar_x(x, y);
}

// ����
double u(double rho, double T)
{
    double x = rho/rho_c, y = T_c/T;
    return R*T*(y*(a0_y(x, y) + ar_y(x, y)));
}

// ��
double h(double rho, double T)
{
    double x = rho/rho_c, y = T_c/T;
    return R*T*(y*(a0_y(x, y) + ar_y(x, y)) + x*ar_x(x, y) + 1);
}

// ��
double s(double rho, double T)
{
    double x = rho/rho_c, y = T_c/T;
    return R*(y*(a0_y(x, y) + ar_y(x, y)) - a_0(x, y) - a_r(x, y));
}

// Gibbs��
double g(double rho, double T)
{
    double x = rho/rho_c, y = T_c/T;
    return R*T*(1 + a_0(x, y) + a_r(x, y) + x*ar_x(x, y));
}

// ���ݱ���
double cv(double rho, double T)
{
    double x = rho/rho_c, y = T_c/T;
    return R*(-y*y*(a0_yy(x, y) + ar_yy(x, y)));
}

// ��ѹ����
double cp(double rho, double T)
{
    double x = rho/rho_c, y = T_c/T;
    return cv(rho, T) + R*(pow(1 + x*ar_x(x, y) - x*y*ar_xy(x, y), 2)/(1 + 2*x*ar_x(x, y) + x*x*ar_xx(x, y)));
}

// ����ƽ��
double w2(double rho, double T)
{
    double x = rho/rho_c, y = T_c/T;
    return R*T*(1 + 2*x*ar_x(x, y) + x*x*ar_xx(x, y) - pow(1 + x*ar_x(x, y) - x*y*ar_xy(x, y), 2)/(y*y*(a0_yy(x, y) + ar_yy(x, y))));
}
*/
// ����ѧƫ��
double p_rho(double rho, double T)
{
    double x = rho/rho_c, y = T_c/T;
    double ar_x, ar_xx;
    ar_x = n1*pow(y, 1.0/4.0) + n3*pow(y, 3.0/2.0) + n2*pow(y, 5.0/4.0) + n9*pow(y, 7.0/2.0)*exp(-x*x) +
            n10*pow(y, 13.0/2.0)*exp(-x*x) + 3*n4*x*x*pow(y, 1.0/4.0) + 7*n5*pow(x, 6.0)*pow(y, 7.0/8.0) +
            n6*pow(y, 19.0/8.0)*exp(-x) - 2*n9*x*x*pow(y, 7.0/2.0)*exp(-x*x) - 2*n10*x*x*pow(y, 13.0/2.0)*exp(-x*x) +
            4*n11*x*x*x*pow(y, 19.0/4.0)*exp(-x*x) - 2*n11*pow(x, 5.0)*pow(y, 19.0/4.0)*exp(-x*x) - 3*n12*pow(x, 4.0)*pow(y, 25.0/2.0)*exp(-x*x*x) +
            2*n7*x*pow(y, 2.0)*exp(-x) - n6*x*pow(y, 19.0/8.0)*exp(-x) - n7*x*x*pow(y, 2.0)*exp(-x) + 5*n8*pow(x, 4.0)*pow(y, 17.0/8.0)*exp(-x) -
            n8*pow(x, 5.0)*pow(y, 17.0/8.0)*exp(-x) + 2*n12*x*pow(y, 25.0/2.0)*exp(-x*x*x);
    ar_xx = 6*n4*x*pow(y, 1.0/4.0) + 2*n12*pow(y, 25.0/2.0)*exp(-x*x*x) + 42*n5*pow(x, 5.0)*pow(y, 7.0/8.0) + 2*n7*pow(y, 2.0)*exp(-x) -
            2*n6*pow(y, 19.0/8.0)*exp(-x) + 4*n9*pow(x, 3.0)*pow(y, 7.0/2.0)*exp(-x*x) + 4*n10*pow(x, 3.0)*pow(y, 13.0/2.0)*exp(-x*x) +
            12*n11*pow(x, 2.0)*pow(y, 19.0/4.0)*exp(-x*x) - 18*n11*pow(x, 4.0)*pow(y, 19.0/4.0)*exp(-x*x) + 4*n11*pow(x, 6.0)*pow(y, 19.0/4.0)*exp(-x*x) -
            18*n12*pow(x, 3.0)*pow(y, 25.0/2.0)*exp(-x*x*x) + 9*n12*pow(x, 6.0)*pow(y, 25.0/2.0)*exp(-x*x*x) - 4*n7*x*pow(y, 2.0)*exp(-x) +
            n6*x*pow(y, 19.0/8.0)*exp(-x) + n7*pow(x, 2.0)*pow(y, 2.0)*exp(-x) - 6*n9*x*pow(y, 7.0/2.0)*exp(-x*x) - 6*n10*x*pow(y, 13.0/2.0)*exp(-x*x) +
            20*n8*pow(x, 3.0)*pow(y, 17.0/8.0)*exp(-x) - 10*n8*pow(x, 4.0)*pow(y, 17.0/8.0)*exp(-x) + n8*pow(x, 5.0)*pow(y, 17.0/8.0)*exp(-x);
    return R*T*(1 + 2*x*ar_x + x*x*ar_xx);
}
/*
double p_rho2(double rho, double T)
{
    double x = rho/rho_c, y = T_c/T;
    return R*T/rho*(2*x*ar_x(x, y) + 4*x*x*ar_xx(x, y) + pow(x, 3)*ar_x3(x, y));
}
*/
double p_T(double rho, double T)
{
    double x = rho/rho_c, y = T_c/T;
    double ar_x, ar_xy;
    ar_x = n1*pow(y, 1.0/4.0) + n3*pow(y, 3.0/2.0) + n2*pow(y, 5.0/4.0) + n9*pow(y, 7.0/2.0)*exp(-x*x) +
            n10*pow(y, 13.0/2.0)*exp(-x*x) + 3*n4*x*x*pow(y, 1.0/4.0) + 7*n5*pow(x, 6.0)*pow(y, 7.0/8.0) +
            n6*pow(y, 19.0/8.0)*exp(-x) - 2*n9*x*x*pow(y, 7.0/2.0)*exp(-x*x) - 2*n10*x*x*pow(y, 13.0/2.0)*exp(-x*x) +
            4*n11*x*x*x*pow(y, 19.0/4.0)*exp(-x*x) - 2*n11*pow(x, 5.0)*pow(y, 19.0/4.0)*exp(-x*x) - 3*n12*pow(x, 4.0)*pow(y, 25.0/2.0)*exp(-x*x*x) +
            2*n7*x*pow(y, 2.0)*exp(-x) - n6*x*pow(y, 19.0/8.0)*exp(-x) - n7*x*x*pow(y, 2.0)*exp(-x) + 5*n8*pow(x, 4.0)*pow(y, 17.0/8.0)*exp(-x) -
            n8*pow(x, 5.0)*pow(y, 17.0/8.0)*exp(-x) + 2*n12*x*pow(y, 25.0/2.0)*exp(-x*x*x);
    ar_xy = (3*n3*pow(y, 1.0/2.0))/2 + (5*n2*pow(y, 1.0/4.0))/4 + n1/(4*pow(y, 3.0/4.0)) + (7*n9*pow(y, 5.0/2.0)*exp(-x*x))/2 + (13*n10*pow(y, 11.0/2.0)*exp(-x*x))/2 +
           (3*n4*x*x)/(4*pow(y, 3.0/4.0)) + (49*n5*pow(x, 6.0))/(8*pow(y, 1.0/8.0)) + (19*n6*pow(y, 11.0/8.0)*exp(-x))/8 - 7*n9*x*x*pow(y, 5.0/2.0)*exp(-x*x) -
            13*n10*x*x*pow(y, 11.0/2.0)*exp(-x*x) + 19*n11*x*x*x*pow(y, 15.0/4.0)*exp(-x*x) - (19*n11*pow(x, 5.0)*pow(y, 15.0/4.0)*exp(-x*x))/2 -
           (75*n12*pow(x, 4.0)*pow(y, 23.0/2.0)*exp(-x*x*x))/2 - 2*n7*x*x*y*exp(-x) - (19*n6*x*pow(y, 11.0/8.0)*exp(-x))/8 + (85*n8*pow(x, 4.0)*pow(y, 9.0/8.0)*exp(-x))/8 -
           (17*n8*pow(x, 5.0)*pow(y, 9.0/8.0)*exp(-x))/8 + 25*n12*x*pow(y, 23.0/2.0)*exp(-x*x*x) + 4*n7*x*y*exp(-x);
    return R*rho*(1 + x*ar_x - x*y*ar_xy);
}

double dudT(double rho, double T)
{
    double x = rho/rho_c, y = T_c/T;
    double a0_yy, ar_yy;
    a0_yy = (u1*u1*v1*exp(-(u1*y)/T_c))/(T_c*T_c*(exp(-(u1*y)/T_c) - 1)) - (c0 - 1)/(y*y) - (u1*u1*v1*exp(-(2*u1*y)/T_c))/(T_c*T_c*(exp(-(u1*y)/T_c) - 1)*(exp(-(u1*y)/T_c) - 1)) +
           (u2*u2*v2*exp(-(u2*y)/T_c))/(T_c*T_c*(exp(-(u2*y)/T_c) - 1)) - (u2*u2*v2*exp(-(2*u2*y)/T_c))/(T_c*T_c*(exp(-(u2*y)/T_c) - 1)*(exp(-(u2*y)/T_c) - 1)) +
           (u3*u3*v3*exp(-(u3*y)/T_c))/(T_c*T_c*(exp(-(u3*y)/T_c) - 1)) - (u3*u3*v3*exp(-(2*u3*y)/T_c))/(T_c*T_c*(exp(-(u3*y)/T_c) - 1)*(exp(-(u3*y)/T_c) - 1));
    ar_yy = (3*n3*x)/(4*pow(y, 0.5)) + (5*n2*x)/(16*pow(y, 0.75)) - (3*n1*x)/(16*pow(y, 1.75)) - (3*n4*x*x*x)/(16*pow(y, 1.75)) - (7*n5*x*x*x*x*x*x)/(64*pow(y, 1.125)) +
            2*n7*x*x*exp(-x) + (285*n11*x*x*x*x*pow(y, 2.75)*exp(-x*x))/16 + (575*n12*x*x*pow(y, 10.5)*exp(-x*x*x))/4 + (209*n6*x*pow(y, 0.375)*exp(-x))/64 +
           (35*n9*x*pow(y, 1.5)*exp(-x*x))/4 + (153*n8*x*x*x*x*pow(y, 0.125)*exp(-x))/64 + (143*n10*x*pow(y, 4.5)*exp(-x*x))/4;
    return R*(-y*y*(a0_yy + ar_yy));
}

double dudD(double rho, double T)
{
    double x = rho/rho_c, y = T_c/T;
    double ar_xy;
    ar_xy = (3*n3*pow(y, 1.0/2.0))/2 + (5*n2*pow(y, 1.0/4.0))/4 + n1/(4*pow(y, 3.0/4.0)) + (7*n9*pow(y, 5.0/2.0)*exp(-x*x))/2 + (13*n10*pow(y, 11.0/2.0)*exp(-x*x))/2 +
           (3*n4*x*x)/(4*pow(y, 3.0/4.0)) + (49*n5*pow(x, 6.0))/(8*pow(y, 1.0/8.0)) + (19*n6*pow(y, 11.0/8.0)*exp(-x))/8 - 7*n9*x*x*pow(y, 5.0/2.0)*exp(-x*x) -
            13*n10*x*x*pow(y, 11.0/2.0)*exp(-x*x) + 19*n11*x*x*x*pow(y, 15.0/4.0)*exp(-x*x) - (19*n11*pow(x, 5.0)*pow(y, 15.0/4.0)*exp(-x*x))/2 -
           (75*n12*pow(x, 4.0)*pow(y, 23.0/2.0)*exp(-x*x*x))/2 - 2*n7*x*x*y*exp(-x) - (19*n6*x*pow(y, 11.0/8.0)*exp(-x))/8 + (85*n8*pow(x, 4.0)*pow(y, 9.0/8.0)*exp(-x))/8 -
           (17*n8*pow(x, 5.0)*pow(y, 9.0/8.0)*exp(-x))/8 + 25*n12*x*pow(y, 23.0/2.0)*exp(-x*x*x) + 4*n7*x*y*exp(-x);
    return R*T/rho*(x*y*(ar_xy));
}
/*
// ��������ѹ
double p_sat(double T)
{
    double A = 37.89875;
    double B1 = -125.3334;
    double B2 = 178.35537;
    double B3 = -133.19653;
    double B4 = 49.70156;
    double B5 = -7.42755;

    return p_c*exp(A + B1*(T_c/T) + B2*pow(T_c/T,2) + B3*pow(T_c/T,3) + B4*pow(T_c/T,4) + B5*pow(T_c/T,5))*1e6;
}


// �ܶ�
double rho(double T, double p)
{
    double rho_0, rho_1;
    double f, f_rho;

    if(p > p_sat(T))
    {
        rho_1 = 800;
    }
    else
    {
        rho_1 = 100;
    }

    for(size_t i = 0; i <1000; i++)
    {
        rho_0 = rho_1;
        f = Z(rho_0, T)*rho_0*R*T - p;
        f_rho = Z(rho_0, T)*R*T + ((rho_0/rho_c)*ar_xx(rho_0/rho_c, T_c/T) + ar_x(rho_0/rho_c, T_c/T))*rho_0*R*T/rho_c;
        rho_1 = rho_1 - f/f_rho;

        if(fabs(rho_1 - rho_0) < rho_acc)
        {
            printf("%d\n", i);
            break;
        }
    }

    return rho_1;
}
*/
/*
int main(int argc, char**argv)
{
    double T = 280, rho = 100;
    printf("Z  =\t%lf\n", Z(rho, T));
    printf("u  =\t%lf\n", u(rho, T)/1e3);
    printf("h  =\t%lf\n", h(rho, T)/1e3);
    printf("s  =\t%lf\n", s(rho, T)/1e3);
    printf("g  =\t%lf\n", g(rho, T)/1e3);
    printf("cv =\t%lf\n", cv(rho, T)/1e3);
    printf("cp =\t%lf\n", cp(rho, T)/1e3);
    printf("w2 =\t%lf\n", sqrt(w2(rho, T)));

    // printf("%lf\n", rho(293, 101325));
    printf("%lf\n", s(20, 293)/1e3);
    printf("%lf\n", cp(20, 293)/1e3);

    printf("dudT  =\t%lf\n", dudT(rho, T));
    printf("dudD  =\t%lf\n", dudD(rho, T));

    return 0;
}
*/
